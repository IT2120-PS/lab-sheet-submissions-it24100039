setwd ("C:\\Users\\it24100039\\Desktop\\it24100039")
getwd()
branch_data<-read.table("Exercise.txt",header = TRUE,sep = "," )
--2

boxplot(branch_data$Sales_X1,
        main = "Boxplot for sales",
        ylab = "Sales",
        col = "Lightblue",
        horizontal = FALSE)
cat("Five-Number Summary for Advertising:\n")
print(summary(branch_data$Advertising_X2))

cat("IQR for Advertising:\n")
print(IQR(branch_data$Advertising_X2))

# Function to find outliers based on IQR
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  x[x < lower_bound | x > upper_bound]
}

# Apply the outlier detection function on the 'Years_X3' column
outliers_years <- find_outliers(branch_data$Years_X3)
cat("Outliers in Years (Years_X3):\n")
print(outliers_years)
